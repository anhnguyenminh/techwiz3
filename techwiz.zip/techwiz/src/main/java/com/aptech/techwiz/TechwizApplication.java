package com.aptech.techwiz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechwizApplication {

    public static void main(String[] args) {
        SpringApplication.run(TechwizApplication.class, args);
    }

}
